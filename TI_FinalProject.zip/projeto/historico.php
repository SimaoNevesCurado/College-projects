<!DOCTYPE html>
<html lang="pt">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="icon" type="image/x-icon" href="assets/images/estg_h.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Jockey+One&amp;family=Poppins:wght@100&amp;family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;family=Source+Code+Pro:ital@1&amp;display=swap">
  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="stylesheet" href="assets/css/dashboard-page.css">
  <link rel="stylesheet" href="assets/css/historico-page.css">
  <style>
    .hidden {
      display: none;
    }
  </style>
  <title>Historico</title>
</head>

<?php
    //para informar o servidor qeue o browser vai usar variáveis de início de sessão
    session_start();
    if(!isset($_SESSION['username'])){   //Se a sessão não estiver iniciada
      header("refresh:2;url=index.php");    //Manda um cabeçalho HTTP ao navegador para dar refresh à página e direcioná-la para o index.php
      die("Acesso restrito");
    }
?>

<body>
  <!--Informação para fazer logout (se desejamos mesmo sair ou não)-->
  <div class="modal fade" id="exampleModal" tabindex="1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Logout</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Tem a certeza que deseja sair da conta atual?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <a href="logout.php" class="btn btn-primary">Sair</a>
        </div>
      </div>
    </div>
  </div>
  <!--FIM DO MODAL -->

  <!--HEADER-->
 <header>
    <div style="margin-top: 70px;" class="container">
      <nav>
        <div class="logo">
          <img src="assets/images/estg_h.png" alt="">
        </div>
        <div class="list-darkmode-menu">
          <!--Menu-->
          <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="#">Historico</a></li>
            <li><a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">Logout</a></li>
          </ul>
          <!-- ICON que muda consoante o tema-->
          <label class="mode">
            <input type="checkbox" checked="checked" id="darkModeButton">
            <i class="fa-solid fa-sun"></i>
            <i class="fa-solid fa-moon"></i>
          </label>
          <!--  botao do Menu que faz parte do mobile e das telas mais pequenas -->
          <button class="hamburger">
            <span class="bar"></span>
          </button>

        </div>
      </nav>
    </div>
  </header>
  <section class="home">

    <div class="container mt-1 mb-3" >
      <!--PAINEIS DE INFORMACAO-->
      <!-- Painel Sensor Temperatura-->
      <div class="container">
        <div class="row">
          <div class="table-buttons">
            <div class="col-md-4">
              <div class="card p-3 mb-2">
                <div class="d-flex justify-content-between">
                  <div class="d-flex flex-row align-items-center">
                    <div class="icon"> <img src="assets/images/temperature-high.png" alt="" style="width:40px"></div>
                    <h3 class="heading"><a href="#" onclick="mostrarTabela('tabelaTemperatura')">&nbsp;Temperatura</a></h3>
                  </div>
                </div>
              </div>
            </div>
            <!-- Painel Sensor Restaurante (clientes)-->
            <div class="col-md-4">
              <div class="card p-3 mb-2">
                <div class="d-flex justify-content-between">
                  <div class="d-flex flex-row align-items-center">
                    <div class="icon"> <img src="assets/images/client.png" alt="" style="width:40px"></div>
                    <h3 class="heading"><a href="#" onclick="mostrarTabela('tabelaClientes')">&nbsp;Clientes</a></h3>
                  </div>
                </div>
              </div>
            </div>
            <!--Painel Sensor Quartos-->
            <div class="col-md-4">
              <div class="card p-3 mb-2">
                <div class="d-flex justify-content-between">
                  <div class="d-flex flex-row align-items-center">
                    <div class="icon"> <img src="assets/images/bed.png" alt="" style="width:40px"></div>
                    <h3 class="heading"><a href="#" onclick="mostrarTabela('tabelaQuarto')">&nbsp;Quartos</a></h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <br>
        <!--TABELAS SENSORES E ATUADORES-->
        <!--Tabela Sensor Temperatura-->
        <table id="tabelaTemperatura" class="table table-striped" style="height: 100% !important;">
        <thead>
            <tr>
                <th scope="col">Histórico</th>
                <th scope="col">Hora e Valor do Sensor</th>
                <th scope="col">Estado do Atuador</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Path to the log file
            $logFile = 'https://iot.dei.estg.ipleiria.pt/ti/g077/projeto/api/api.php?nome=temperatura&field=log&api_chave=1234';

            // Read the log file into an array of lines
            $ficheiro_temperatura_sensor = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $contador_sensor = count($ficheiro_temperatura_sensor);

            // Get the last 15 logs
            $latestLogs = array_slice($ficheiro_temperatura_sensor, -15);
            $numero_historico = $contador_sensor - count($latestLogs) + 1;

            // Iterate through the latest logs
            foreach ($latestLogs as $log_temperatura_sensor) {
                if ($log_temperatura_sensor) {
                    $valor_temperatura = explode(":", $log_temperatura_sensor);  // Assuming the log format allows this
                    
                    // Determine the state of the actuator based on the sensor value
                    if ($valor_temperatura[3] < 18) {
                        $log_temperatura_atuador = "Ar condicionado ligado : Quente";
                    } elseif ($valor_temperatura[3] >= 18 && $valor_temperatura[3] <= 21) {
                        $log_temperatura_atuador = "Ar condicionado desligado";
                    } else {
                        $log_temperatura_atuador = "Ar condicionado ligado : Frio";
                    }
                } else {
                    $log_temperatura_sensor = "Sem logs";
                    $log_temperatura_atuador = "Sem logs";
                }

                // Add the row to the table
                echo "<tr>";
                echo "<td>{$numero_historico}</td>";
                echo "<td>{$log_temperatura_sensor}</td>";
                echo "<td>{$log_temperatura_atuador}</td>";
                echo "</tr>";

                $numero_historico++;
            }
            ?>
        </tbody>
    </table>
    <!--Tabela Sensor Restaurante (Clientes)-->        
    <table id="tabelaClientes" class="table table-striped hidden">
        <thead>
            <tr>
                <th scope="col">Histórico</th>
                <th scope="col">Hora e Valor do Sensor</th>
                <th scope="col">Estado do Atuador</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Path to the log file
            $logFile = 'https://iot.dei.estg.ipleiria.pt/ti/g077/projeto/api/api.php?nome=clientes&field=log&api_chave=1234';

            // Read the log file into an array of lines
            $ficheiro_clientes_sensor = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $contador_sensor = count($ficheiro_clientes_sensor);

            // Get the last 15 logs
            $latestLogs = array_slice($ficheiro_clientes_sensor, -15);
            $numero_historico = $contador_sensor - count($latestLogs) + 1;

            // Iterate through the latest logs
            foreach ($latestLogs as $log_clientes_sensor) {
                if ($log_clientes_sensor) {
                    $valor_clientes = explode(":", $log_clientes_sensor);  // Assuming the log format allows this
                    
                    // Determine the state of the actuator based on the sensor value
                    if ($valor_clientes[3] >= 0 && $valor_clientes[3] < 20) {
                        $log_clientes_atuador = "Restaurante OK";
                    } elseif ($valor_clientes[3] >= 20 && $valor_clientes[3] < 40) {
                        $log_clientes_atuador = "Restaurante Estável";
                    } else {
                        $log_clientes_atuador = "Restaurante Cheio";
                    }
                } else {
                    $log_clientes_sensor = "Sem logs";
                    $log_clientes_atuador = "Sem logs";
                }

                // Add the row to the table
                echo "<tr>";
                echo "<td>{$numero_historico}</td>";
                echo "<td>{$log_clientes_sensor}</td>";
                echo "<td>{$log_clientes_atuador}</td>";
                echo "</tr>";

                $numero_historico++;
            }
            ?>
        </tbody>
    </table>

              
        <table id="tabelaQuarto" class="table table-striped">
        <thead>
            <tr>
                <th scope="col">Histórico</th>
                <th scope="col">Hora e Valor do Sensor</th>
                <th scope="col">Estado do Atuador</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Path to the log file
            $logFile = 'https://iot.dei.estg.ipleiria.pt/ti/g077/projeto/api/api.php?nome=quartos&field=log&api_chave=1234';

            // Read the log file into an array of lines
            $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $totalLogs = count($lines);

            // Get the last 15 logs
            $latestLogs = array_slice($lines, -15);
            $numero_historico = $totalLogs - count($latestLogs) + 1;

            // Iterate through the latest logs
            foreach ($latestLogs as $log_quarto_sensor) {
                if ($log_quarto_sensor) {
                    $valor_quarto = explode(":", $log_quarto_sensor);  // Assuming the log format allows this
                    
                    // Determine the state of the actuator based on the sensor value
                    if ($valor_quarto[3] >= 0 && $valor_quarto[3] < 50) {
                        $log_quarto_atuador = "Quartos Parcialmente Vazios";
                    } elseif ($valor_quarto[3] >= 50 && $valor_quarto[3] < 100) {
                        $log_quarto_atuador = "Quartos quase cheios";
                    } else {
                        $log_quarto_atuador = "Quartos cheios";
                    }
                } else {
                    $log_quarto_sensor = "Sem logs";
                    $log_quarto_atuador = "Sem logs";
                }

                // Add the row to the table
                echo "<tr>";
                echo "<td>{$numero_historico}</td>";
                echo "<td>{$log_quarto_sensor}</td>";
                echo "<td>{$log_quarto_atuador}</td>";
                echo "</tr>";

                $numero_historico++;
            }
            ?>
        </tbody>
    </table>
      </div>
    </div>
  </section>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>


   <!--Para poder mostrar as tabelas específicas -->
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      // Oculta todas as tabelas inicialmente
      var tabelas = document.querySelectorAll('table');
      tabelas.forEach(function (tabela) {
        tabela.classList.add('hidden'); // Adiciona a classe 'hidden' para ocultar a tabela
      });
    });

    
function mostrarTabela(idTabela) {
    // Seleciona todas as tabelas que existem
    var tabelas = document.querySelectorAll('table');
      // Oculta todas as tabelas
      tabelas.forEach(function (tabela) {
        tabela.classList.add('hidden'); // Define o estilo de exibição como 'none' para ocultar a tabela
      });
      // Exibe a tabela específica com o ID fornecido
      document.getElementById(idTabela).classList.remove('hidden'); // Define o estilo de exibição como 'table' para exibir a tabela
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/dashboard.js"></script>
</body>

</html>