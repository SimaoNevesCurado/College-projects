
//funcao java script que faz com que os nomes propostos passem uns a seguir aos outros
const typed = new Typed('.multiple', {

  strings: ['Simão Curado', 'Ana Alves'], // nomes exibidos
  typeSpeed: 100, // velocidade ao escrever
  backSpeed: 100, // velocidade ao apagar
  backDelay: 1000, // tempo que depois de apagado , volta a escrever
  loop: true //loop

});

