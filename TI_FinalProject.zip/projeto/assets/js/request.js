

document.getElementById("removeCustomerButton").addEventListener("click", function (event) {
    event.preventDefault(); // Prevent any default action (e.g., form submission)

    var url = 'https://iot.dei.estg.ipleiria.pt/ti/g077/projeto/api/api.php';

    const customerCountElement = document.getElementById('customerCount');
    const customerCountElement2 = document.getElementById('customerCount2');
    const customerCountElement3 = document.getElementById('customerCount3');

    let customerCount = parseInt(customerCountElement.innerText);


    if (customerCount > 0) {
        customerCount--;  // Decrease the customer count by 1

        var date = new Date();
        var dia = ("0" + date.getDate()).slice(-2);
        var mes = ("0" + (date.getMonth() + 1)).slice(-2);
        var ano = date.getFullYear();
        let options = { hour: "2-digit", minute: "2-digit", second: "2-digit" };
        var hora = `${dia}-${mes}-${ano} ${date.toLocaleTimeString("pt-PT", options)}`;


        var params = {
            nome: 'quartos',
            valor: customerCount,
            hora: hora,
            api_chave: '1234'
        };

        $.ajax({
            type: 'POST',
            dataType: "text",
            url: url,
            data: params,
            contentType: 'application/x-www-form-urlencoded',
            success: function (response) {

                console.log(response)

                customerCountElement2.innerText = customerCount + ' ';
                customerCountElement.innerText = customerCount + ' ';
                customerCountElement3.innerText = customerCount + ' ';
            },
            error: function (xhr, status, error) {
                console.log('Error: ' + xhr.status + ' - ' + error); // Handle errors
            }

        });
    }
});

document.getElementById("TurnOFFfan").addEventListener("click", function (event) {
    event.preventDefault(); // Prevent any default action (e.g., form submission)

    var url = 'https://iot.dei.estg.ipleiria.pt/ti/g077/projeto/api/api.php';

    const TurnOFFfanElement = document.getElementById('fanvalue');
    const TurnOFFfanElement2 = document.getElementById('fanvalue2');
    const TurnOFFfanElement3 = document.getElementById('fanvalue3');

    const badge = $('#badgeprogress');
    const tempbadge = $('#tempbadge');
    const tempbadgetext = $('#tempbadgetext');

    var date = new Date();
    var dia = ("0" + date.getDate()).slice(-2);
    var mes = ("0" + (date.getMonth() + 1)).slice(-2);
    var ano = date.getFullYear();
    let options = { hour: "2-digit", minute: "2-digit", second: "2-digit" };
    var hora = `${dia}-${mes}-${ano} ${date.toLocaleTimeString("pt-PT", options)}`;

    fanvalue = 19;

    percent_Temperatura = (19 * 100) / 25;

    var params = {
        nome: 'temperatura',
        valor: fanvalue,
        hora: hora,
        api_chave: '1234'
    };

    $.ajax({
        type: 'POST',
        dataType: "text",
        url: url,
        data: params,
        contentType: 'application/x-www-form-urlencoded',
        success: function (response) {

            console.log(response)

            TurnOFFfanElement.innerText = fanvalue + ' ';
            TurnOFFfanElement2.innerText = fanvalue;
            TurnOFFfanElement3.innerText = fanvalue;

            badge.attr('class', 'progress-bar bg-secondary')
                .attr('style', 'width:' + percent_Temperatura + '%')
                .attr('aria-valuenow', 50)
                .attr('aria-valuemin', '0')
                .attr('aria-valuemax', '100');

            // Verifica se o elemento de texto foi encontrado
            if (tempbadgetext.length) {
                // Atualiza a classe do botão
                tempbadge.attr('class', 'btn btn-secondary');

                // Atualiza o texto dentro do elemento de texto
                tempbadgetext.text('Ar condicionado desligado');
            } else {
                console.error('Elemento "#tempbadgetext" não encontrado.');
            }


        },
        error: function (xhr, status, error) {
            console.log('Error: ' + xhr.status + ' - ' + error); // Handle errors
        }

    });

});

function updateDataQuart() {
    $.ajax({
        url: "https://iot.dei.estg.ipleiria.pt/ti/g077/projeto/api/api.php?nome=quartos&field=valor&api_chave=1234",
        method: "GET",
        dataType: "text",
        success: function (data) {
            const value = parseFloat(data);
            var span = $('#customerCount');
            var span2 = $('#customerCount2');
            var span3 = $('#customerCount3');
            var horamudar = $('#hora_quarto');
            var horamudar2 = $('#hora_quarto2');

            const badge = $('#quartbadgeprogress');
            const quartbadge = $('#quartbadge');
            const quartbadgetext = $('#quartbadgetext');


            span.html(value + ' ');
            span2.html(value + ' ');
            span3.html(value + ' ');

            var date = new Date();
            var dia = ("0" + date.getDate()).slice(-2);
            var mes = ("0" + (date.getMonth() + 1)).slice(-2);
            var ano = date.getFullYear();
            let options = { hour: "2-digit", minute: "2-digit", second: "2-digit" };
            var hora = `${dia}-${mes}-${ano} ${date.toLocaleTimeString("pt-PT", options)}`;

            horamudar.html(' ' + hora);
            horamudar2.html(' ' + hora);


            controlo = value;
         // Atualiza o estilo e texto do quartbadge com base no valor de quartos
if (quartbadgetext.length) {
    if (value >= 0 && value < 50) {
        quartbadge.attr('class', 'btn btn-success');
        quartbadgetext.text('Quartos Parcialmente Vazios');

        badge.attr('class', 'progress-bar bg-success')
            .attr('style', 'width:' + controlo + '%')
            .attr('aria-valuenow', controlo )
            .attr('aria-valuemin', '0')
            .attr('aria-valuemax', '100');

    } else if (value >= 50 && value < 100) {
        quartbadge.attr('class', 'btn btn-warning');
        quartbadgetext.text('Quartos Quase Cheios');

        badge.attr('class', 'progress-bar bg-warning')
            .attr('style', 'width:' + controlo  + '%')
            .attr('aria-valuenow', controlo )
            .attr('aria-valuemin', '0')
            .attr('aria-valuemax', '100');
    } else {
        quartbadge.attr('class', 'btn btn-danger');
        quartbadgetext.text('Quartos Cheios');

        badge.attr('class', 'progress-bar bg-danger')
            .attr('style', 'width:' + controlo  + '%')
            .attr('aria-valuenow', controlo )
            .attr('aria-valuemin', '0')
            .attr('aria-valuemax', '100');
    }
} else {
    console.error('Elemento "#quartbadgetext" não encontrado.');
}






        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.error(textStatus);
        }
    });
}
function updateDataClient() {
    $.ajax({
        url: "https://iot.dei.estg.ipleiria.pt/ti/g077/projeto/api/api.php",
        method: "GET",
        data: {
            nome: "clientes",
            field: "valor",
            api_chave: 1234
        },
        dataType: "text",
        success: function (data) {
            const value = parseFloat(data);

            // Seleciona os elementos onde os dados serão inseridos
            var span3 = $('#valor_cliente3');
            var span2 = $('#valor_cliente2');
            var span = $('#valor_cliente');
            var horamudar = $('#hora_cliente');
            var horamudar2 = $('#hora_cliente2');

            const badge = $('#clientbadgeprogress');
            const clientbadge = $('#clientbadge');
            const clientbadgetext = $('#clientbadgetext');




            // Atualiza os valores dos clientes nos spans
            span.html(value + ' ');
            span2.html(value + ' ');
            span3.html(value + ' ');

            // Formata a hora atual
            var date = new Date();
            var dia = ("0" + date.getDate()).slice(-2);
            var mes = ("0" + (date.getMonth() + 1)).slice(-2);
            var ano = date.getFullYear();
            let options = { hour: "2-digit", minute: "2-digit", second: "2-digit" };
            var hora = `${dia}-${mes}-${ano} ${date.toLocaleTimeString("pt-PT", options)}`;

            // Insere a hora formatada nos elementos correspondentes
            horamudar.html(' ' + hora);
            horamudar2.html(' ' + hora);

            percent_clientes = (value * 100) / 40;

            // Atualiza o estilo e texto do clientbadge com base no valor de clientes
            if (clientbadgetext.length) {
                if (value >= 0 && value < 20) {
                    clientbadge.attr('class', 'btn btn-success');
                    clientbadgetext.text('Restaurante OK');

                    badge.attr('class', 'progress-bar bg-success')
                        .attr('style', 'width:' + percent_clientes + '%')
                        .attr('aria-valuenow', percent_clientes)
                        .attr('aria-valuemin', '0')
                        .attr('aria-valuemax', '100');
                } else if (value >= 20 && value < 40) {
                    clientbadge.attr('class', 'btn btn-warning');
                    clientbadgetext.text('Restaurante Estável');

                    badge.attr('class', 'progress-bar bg-warning')
                        .attr('style', 'width:' + percent_clientes + '%')
                        .attr('aria-valuenow', percent_clientes)
                        .attr('aria-valuemin', '0')
                        .attr('aria-valuemax', '100');
                } else {

                    clientbadge.attr('class', 'btn btn-danger');
                    clientbadgetext.text('Restaurante Cheio');

                    badge.attr('class', 'progress-bar bg-danger')
                        .attr('style', 'width:' + percent_clientes + '%')
                        .attr('aria-valuenow', percent_clientes)
                        .attr('aria-valuemin', '0')
                        .attr('aria-valuemax', '100');
                }
            } else {
                console.error('Elemento "#clientbadgetext" não encontrado.');
            }

        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.error("Erro na requisição AJAX:", textStatus, errorThrown);
        }
    });
}


function updateDataTemp() {
    $.ajax({
        url: "https://iot.dei.estg.ipleiria.pt/ti/g077/projeto/api/api.php?nome=temperatura&field=valor&api_chave=1234",
        method: "GET",
        dataType: "text",
        success: function (data) {
            const value = parseFloat(data);
            var span3 = $('#fanvalue3');
            var span2 = $('#fanvalue2');
            var span = $('#fanvalue');
            var horamudar = $('#hora_temperatura');
            var horamudar2 = $('#hora_temp');


            const badge = $('#badgeprogress');
            const tempbadge = $('#tempbadge');
            const tempbadgetext = $('#tempbadgetext');

            span.html(value + ' ');
            span2.html(value + ' ');
            span3.html(value + ' ');

            var date = new Date();
            var dia = ("0" + date.getDate()).slice(-2);
            var mes = ("0" + (date.getMonth() + 1)).slice(-2);
            var ano = date.getFullYear();
            let options = { hour: "2-digit", minute: "2-digit", second: "2-digit" };
            var hora = `${dia}-${mes}-${ano} ${date.toLocaleTimeString("pt-PT", options)}`;

            horamudar.html(' ' + hora);
            horamudar2.html(' ' + hora);


            var percent_clientes = (value * 100) / 30;
            if (tempbadgetext.length) {
                if (value < 18) {
                    tempbadge.attr('class', 'btn btn-warning');
                    tempbadgetext.text('Ar condicionado ligado : Quente');

                    badge.attr('class', 'progress-bar bg-warning')
                        .attr('style', 'width:' + percent_clientes + '%')
                        .attr('aria-valuenow', percent_clientes)
                        .attr('aria-valuemin', '0')
                        .attr('aria-valuemax', '100');
                } else if (value >= 18 && value <= 21) {
                    tempbadge.attr('class', 'btn btn-secondary');
                    tempbadgetext.text('Ar condicionado desligado');

                    badge.attr('class', 'progress-bar bg-secondary')
                        .attr('style', 'width:' + percent_clientes + '%')
                        .attr('aria-valuenow', percent_clientes)
                        .attr('aria-valuemin', '0')
                        .attr('aria-valuemax', '100');
                } else {
                    tempbadge.attr('class', 'btn btn-primary');
                    tempbadgetext.text('Ar condicionado ligado : Frio');

                    badge.attr('class', 'progress-bar bg-primary')
                        .attr('style', 'width:' + percent_clientes + '%')
                        .attr('aria-valuenow', percent_clientes)
                        .attr('aria-valuemin', '0')
                        .attr('aria-valuemax', '100');
                }
            } else {
                console.error('Elemento "#tempbadgetext" não encontrado.');
            }


        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.error(textStatus);
        }
    });
}

setInterval(updateDataTemp, 1000);
setInterval(updateDataClient, 1000);
setInterval(updateDataQuart, 1000);


