import cv2
import requests

# URL da webcam (neste caso, uma imagem estática de exemplo)
webcam_url = "https://porto.winebookshotels.com/wp-content/uploads/sites/3/2023/04/JoseManuelFerrao2023_027-1920x1279.jpg"

# Abre a captura de vídeo a partir da URL da webcam
cap = cv2.VideoCapture(webcam_url)
ret, frame = cap.read()  # Lê um frame da captura de vídeo
if ret:
    # Se a captura foi bem-sucedida, escreve o frame em um arquivo JPEG
    cv2.imwrite('captura.jpg', frame)  # Salva a imagem na mesma diretoria do script
cap.release()  # Libera a captura de vídeo

# Define a URL do servidor onde a imagem será carregada
url = 'https://iot.dei.estg.ipleiria.pt/ti/g077/projeto/api/upload.php'
# Abre o arquivo da imagem salva em modo de leitura binária
files = {'imagem': open('captura.jpg', 'rb')}

# Envia uma requisição POST para o servidor com a imagem
r = requests.post(url, files=files)

# Comentários explicativos:
# 1. Importa os módulos necessários: cv2 (OpenCV) para manipulação de imagens e requests para requisições HTTP.
# 2. Define a URL da webcam. Neste exemplo, é uma URL de uma imagem estática.
# 3. Abre a captura de vídeo a partir da URL da webcam.
# 4. Lê um frame da captura de vídeo.
# 5. Se a leitura do frame for bem-sucedida, guarda a imagem capturada como "captura.jpg" na mesma diretoria do script.
# 6. Libera a captura de vídeo.
# 7. Define a URL do servidor para onde a imagem será enviada.
# 8. Abre o arquivo "captura.jpg" em modo de leitura binária.
# 9. Envia uma requisição POST para o servidor com o arquivo de imagem anexado.