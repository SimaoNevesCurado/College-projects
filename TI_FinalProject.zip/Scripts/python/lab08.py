import RPi.GPIO as GPIO
import requests
import time

# Configura o modo dos pinos GPIO
GPIO.setmode(GPIO.BCM)
ventoinha_PIN = 2  # Define o pino para o relé da ventoinha
button_PIN = 3    # Define o pino para o botão

# Configura os pinos de saída e entrada
GPIO.setup(ventoinha_PIN, GPIO.OUT)  # Configura o pino da ventoinha como saída
GPIO.setup(button_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # Configura o pino do botão como entrada com pull-up

print("--- Prima CTRL + C para terminar ---")

try:
    while True:
        # Obtém a quantidade de hóspedes atual da API
        valor_quartos = requests.get('http://iot.dei.estg.ipleiria.pt/ti/g077/projeto/api/api.php?nome=quartos&field=valor&api_chave=1234')
        print(f"Quantidade de hóspedes atual: {valor_quartos.text}")

        # Verifica se o botão foi pressionado
        if GPIO.input(button_PIN) == GPIO.LOW:
            # Se a resposta da API for bem-sucedida
            if valor_quartos.status_code == 200:
                numero = int(valor_quartos.text)  # Converte o texto da resposta para um número inteiro
                numero += 1  # Incrementa o número de hóspedes
            else:
                print("Erro ao obter valor dos quartos")
            
            print("Adicionei um hóspede")
            
            # Prepara os dados para envio à API
            hora_atual = time.strftime('%Y-%m-%d %H:%M:%S')  # Obtém a hora atual
            payload = {'nome': 'quartos', 'valor': numero, 'hora': hora_atual, 'api_chave': '1234'}
            
            # Envia o novo valor para a API
            clientes_sensor = requests.post('http://iot.dei.estg.ipleiria.pt/ti/g077/projeto/api/api.php', data=payload)
            
            # Debounce para evitar múltiplos registros
            time.sleep(0.3)

        # Obtém o valor da temperatura para controlar a ventoinha
        temperatura_atuador = requests.get('http://iot.dei.estg.ipleiria.pt/ti/g077/projeto/api/api.php?nome=temperatura&field=valor&api_chave=1234')

        # Verifica se a resposta da API foi bem-sucedida
        if temperatura_atuador.status_code == 200:
            print("Temperatura na API: ", temperatura_atuador.text)
            # Liga o relé se a temperatura for maior que 20 graus
            if float(temperatura_atuador.text) > 20:
                print("Vou ligar o relé da RPI")
                GPIO.output(ventoinha_PIN, GPIO.HIGH)  # Liga o relé que simula uma ventoinha
            # Desliga o relé se a temperatura for menor ou igual a 20 graus
            else:
                print("Vou desligar o relé da RPI")
                GPIO.output(ventoinha_PIN, GPIO.LOW)  # Desliga o relé que simula uma ventoinha
        else:
            print("Erro no pedido HTTP")
        
        # Aguarda 5 segundos antes de repetir o loop
        time.sleep(5)

# Trata a interrupção do programa pelo utilizador
except KeyboardInterrupt:
    print("\nPrograma Parado pelo Utilizador")
# Trata outros erros inesperados
except Exception as e:
    print('\nErro inesperado:', e)
    print("Tenta outra vez")
# Limpa a configuração dos GPIO ao finalizar
finally:
    GPIO.cleanup()
    print('Terminou o programa')
